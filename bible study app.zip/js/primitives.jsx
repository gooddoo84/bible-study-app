// Shared UI primitives
const Icon = {
  home: (s=22, c='currentColor') => <svg width={s} height={s} viewBox="0 0 24 24" fill="none"><path d="M3 10.5L12 3l9 7.5V20a1 1 0 01-1 1h-5v-7h-6v7H4a1 1 0 01-1-1v-9.5z" stroke={c} strokeWidth="1.8" strokeLinejoin="round"/></svg>,
  book: (s=22, c='currentColor') => <svg width={s} height={s} viewBox="0 0 24 24" fill="none"><path d="M4 4.5A1.5 1.5 0 015.5 3H11v17H5.5A1.5 1.5 0 014 18.5v-14zM20 4.5A1.5 1.5 0 0018.5 3H13v17h5.5a1.5 1.5 0 001.5-1.5v-14z" stroke={c} strokeWidth="1.6"/></svg>,
  chart: (s=22, c='currentColor') => <svg width={s} height={s} viewBox="0 0 24 24" fill="none"><path d="M4 19V9m6 10V5m6 14v-7" stroke={c} strokeWidth="2" strokeLinecap="round"/></svg>,
  users: (s=22, c='currentColor') => <svg width={s} height={s} viewBox="0 0 24 24" fill="none"><circle cx="9" cy="8" r="3.2" stroke={c} strokeWidth="1.6"/><path d="M3 19c0-3.3 2.7-6 6-6s6 2.7 6 6" stroke={c} strokeWidth="1.6" strokeLinecap="round"/><circle cx="17" cy="9" r="2.5" stroke={c} strokeWidth="1.6"/><path d="M15 14c3 0 6 1.7 6 5" stroke={c} strokeWidth="1.6" strokeLinecap="round"/></svg>,
  user: (s=18, c='currentColor') => <svg width={s} height={s} viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="4" stroke={c} strokeWidth="1.6"/><path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8" stroke={c} strokeWidth="1.6" strokeLinecap="round"/></svg>,
  settings: (s=18, c='currentColor') => <svg width={s} height={s} viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="3" stroke={c} strokeWidth="1.6"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 01-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09a1.65 1.65 0 00-1-1.51 1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09a1.65 1.65 0 001.51-1 1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06a1.65 1.65 0 001.82.33 1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82 1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z" stroke={c} strokeWidth="1.4"/></svg>,
  flame: (s=16, c='currentColor') => <svg width={s} height={s} viewBox="0 0 24 24" fill={c}><path d="M12 2c0 5-5 6-5 11 0 3.3 2.7 6 5 6s5-2.7 5-6c0-2-1-3-2-4 0-2-1-4-3-7z"/></svg>,
  check: (s=16, c='currentColor') => <svg width={s} height={s} viewBox="0 0 24 24" fill="none"><path d="M5 12l4.5 4.5L19 7" stroke={c} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  chevR: (s=14, c='currentColor') => <svg width={s} height={s} viewBox="0 0 24 24" fill="none"><path d="M9 6l6 6-6 6" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  chevL: (s=14, c='currentColor') => <svg width={s} height={s} viewBox="0 0 24 24" fill="none"><path d="M15 6l-6 6 6 6" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  x: (s=18, c='currentColor') => <svg width={s} height={s} viewBox="0 0 24 24" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke={c} strokeWidth="1.8" strokeLinecap="round"/></svg>,
  heart: (s=18, c='currentColor', fill='none') => <svg width={s} height={s} viewBox="0 0 24 24" fill={fill}><path d="M12 20s-7-4.5-7-10a4 4 0 017-2.6A4 4 0 0119 10c0 5.5-7 10-7 10z" stroke={c} strokeWidth="1.6" strokeLinejoin="round"/></svg>,
  message: (s=18, c='currentColor') => <svg width={s} height={s} viewBox="0 0 24 24" fill="none"><path d="M4 6a2 2 0 012-2h12a2 2 0 012 2v9a2 2 0 01-2 2H9l-4 4v-4H6a2 2 0 01-2-2V6z" stroke={c} strokeWidth="1.6" strokeLinejoin="round"/></svg>,
  play: (s=16, c='currentColor') => <svg width={s} height={s} viewBox="0 0 24 24" fill={c}><path d="M7 5v14l12-7L7 5z"/></svg>,
  plus: (s=18, c='currentColor') => <svg width={s} height={s} viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke={c} strokeWidth="2" strokeLinecap="round"/></svg>,
  sparkle: (s=18, c='#B86F3C') => <svg width={s} height={s} viewBox="0 0 24 24" fill="none"><path d="M12 2l1.8 6.2L20 10l-6.2 1.8L12 18l-1.8-6.2L4 10l6.2-1.8L12 2z" fill={c}/></svg>,
  drop: (s=18, c='#8F6B8F') => <svg width={s} height={s} viewBox="0 0 24 24" fill="none"><path d="M12 3c-4 6-6 9-6 12a6 6 0 0012 0c0-3-2-6-6-12z" stroke={c} strokeWidth="1.6" fill={c + '22'}/></svg>,
  sprout: (s=18, c='#6B8273') => <svg width={s} height={s} viewBox="0 0 24 24" fill="none"><path d="M12 21v-7M12 14c0-3 2-6 6-6 0 4-3 6-6 6zM12 14c0-3-2-5-5-5 0 3 2 5 5 5z" stroke={c} strokeWidth="1.6" strokeLinejoin="round"/></svg>,
  star: (s=18, c='#A67C52') => <svg width={s} height={s} viewBox="0 0 24 24" fill={c}><path d="M12 2l2.6 6.6L22 9.4l-5.5 4.8L18.2 22 12 18.3 5.8 22l1.7-7.8L2 9.4l7.4-.8L12 2z"/></svg>,
  logout: (s=18, c='currentColor') => <svg width={s} height={s} viewBox="0 0 24 24" fill="none"><path d="M15 3h3a2 2 0 012 2v14a2 2 0 01-2 2h-3M10 17l-5-5 5-5M5 12h12" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  key: (s=18, c='currentColor') => <svg width={s} height={s} viewBox="0 0 24 24" fill="none"><circle cx="8" cy="15" r="4" stroke={c} strokeWidth="1.6"/><path d="M11 12l9-9M16 5l3 3" stroke={c} strokeWidth="1.6" strokeLinecap="round"/></svg>,
  doc: (s=18, c='currentColor') => <svg width={s} height={s} viewBox="0 0 24 24" fill="none"><path d="M6 3h9l5 5v13a1 1 0 01-1 1H6a1 1 0 01-1-1V4a1 1 0 011-1zM14 3v6h6" stroke={c} strokeWidth="1.6" strokeLinejoin="round"/></svg>,
  ai: (s=18, c='currentColor') => <svg width={s} height={s} viewBox="0 0 24 24" fill="none"><path d="M12 2l1.5 4.5L18 8l-4.5 1.5L12 14l-1.5-4.5L6 8l4.5-1.5L12 2zM5 16l.8 2.2L8 19l-2.2.8L5 22l-.8-2.2L2 19l2.2-.8L5 16zM19 14l.6 1.6 1.6.6-1.6.6L19 18.4 18.4 16.8 16.8 16.2 18.4 15.6 19 14z" fill={c}/></svg>,
};

function StepIcon({ id, size = 20 }) {
  const s = SEVEN_STEPS.find(x => x.id === id);
  if (!s) return null;
  const map = { book: Icon.book, sparkle: Icon.sparkle, heart: Icon.heart, drop: Icon.drop, sprout: Icon.sprout, users: Icon.users, star: Icon.star };
  const Fn = map[s.icon];
  return Fn ? Fn(size, s.color) : null;
}

function Ring({ progress = 0, size = 64, stroke = 5, color = '#C9A961', bg = 'rgba(58,53,48,0.08)', children }) {
  const r = (size - stroke) / 2;
  const C = 2 * Math.PI * r;
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size/2} cy={size/2} r={r} stroke={bg} strokeWidth={stroke} fill="none"/>
        <circle cx={size/2} cy={size/2} r={r} stroke={color} strokeWidth={stroke} fill="none"
          strokeLinecap="round" strokeDasharray={C} strokeDashoffset={C * (1 - progress)}
          style={{ transition: 'stroke-dashoffset 0.6s cubic-bezier(0.22,1,0.36,1)' }}/>
      </svg>
      {children && <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{children}</div>}
    </div>
  );
}

function TabBar({ active, onChange }) {
  const tabs = [
    { id: 'home', label: '오늘', icon: Icon.home },
    { id: 'read', label: '성경', icon: Icon.book },
    { id: 'stats', label: '성장', icon: Icon.chart },
    { id: 'share', label: '나눔', icon: Icon.users },
    { id: 'settings', label: '설정', icon: Icon.settings },
  ];
  return (
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0,
      padding: '8px 4px 24px',
      background: 'rgba(245, 241, 232, 0.88)',
      backdropFilter: 'blur(20px) saturate(180%)',
      WebkitBackdropFilter: 'blur(20px) saturate(180%)',
      borderTop: '0.5px solid rgba(58,53,48,0.08)',
      display: 'flex', justifyContent: 'space-around', zIndex: 40,
    }}>
      {tabs.map(t => {
        const isActive = active === t.id;
        return (
          <button key={t.id} onClick={() => onChange(t.id)} className="press" style={{
            background: 'none', border: 'none', padding: '6px 6px',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
            color: isActive ? 'var(--gold-deep)' : 'rgba(58,53,48,0.45)',
            cursor: 'pointer', transition: 'color 0.2s',
          }}>
            {t.icon(21)}
            <span style={{ fontSize: 9.5, fontWeight: 600, whiteSpace: 'nowrap' }}>{t.label}</span>
          </button>
        );
      })}
    </div>
  );
}

function StatusBar({ time }) {
  const t = time || new Date().toTimeString().slice(0, 5);
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '18px 30px 6px', fontFamily: '-apple-system, system-ui',
      fontSize: 16, fontWeight: 600, color: 'var(--ink-2)',
    }}>
      <div>{t}</div>
      <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
        <svg width="17" height="11" viewBox="0 0 19 12"><rect x="0" y="7.5" width="3.2" height="4.5" rx="0.7" fill="currentColor"/><rect x="4.8" y="5" width="3.2" height="7" rx="0.7" fill="currentColor"/><rect x="9.6" y="2.5" width="3.2" height="9.5" rx="0.7" fill="currentColor"/><rect x="14.4" y="0" width="3.2" height="12" rx="0.7" fill="currentColor"/></svg>
        <svg width="25" height="12" viewBox="0 0 27 13"><rect x="0.5" y="0.5" width="23" height="12" rx="3.5" stroke="currentColor" strokeOpacity="0.5" fill="none"/><rect x="2" y="2" width="18" height="9" rx="2" fill="currentColor"/></svg>
      </div>
    </div>
  );
}

function HomeIndicator() {
  return (
    <div style={{ position: 'absolute', bottom: 8, left: 0, right: 0, display: 'flex', justifyContent: 'center', zIndex: 100, pointerEvents: 'none' }}>
      <div style={{ width: 139, height: 5, borderRadius: 100, background: 'rgba(43,38,32,0.35)' }}/>
    </div>
  );
}

// Pretty date formatter
function fmtDate(d = new Date()) {
  const w = ['일','월','화','수','목','금','토'][d.getDay()];
  return `${d.getMonth() + 1}월 ${d.getDate()}일 ${w}요일`;
}

// Sleep
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

Object.assign(window, { Icon, StepIcon, Ring, TabBar, StatusBar, HomeIndicator, fmtDate, sleep });
