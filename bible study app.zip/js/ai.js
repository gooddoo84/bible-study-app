// AI summary helper via Anthropic API
// API key is stored in localStorage by the user (Settings screen).
window.AI = {
  getKey() { return localStorage.getItem('mk_anthropic_key') || ''; },
  setKey(k) { localStorage.setItem('mk_anthropic_key', k || ''); },
  hasKey() { return !!this.getKey(); },

  async summarize(chapter, verses) {
    const key = this.getKey();
    if (!key) throw new Error('API 키가 설정되지 않았습니다. 설정 → AI 키 등록에서 추가해주세요.');
    const body = {
      model: 'claude-haiku-4-5',
      max_tokens: 700,
      messages: [{
        role: 'user',
        content: `다음은 ${chapter} 본문입니다. 한국 기독교인이 QT(묵상) 시간에 도움이 되도록 다음 3가지를 간결하고 따뜻한 한국어로 정리해 주세요. 각 항목 2-3문장 이내.\n\n1) 본문 한눈에 보기 (핵심 흐름)\n2) 오늘 발견할 한 구절 (구절 번호 + 짧은 이유)\n3) 적용을 위한 질문 1가지\n\n본문:\n${verses.map(v => `${v.n}. ${v.t}`).join('\n')}`
      }]
    };
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': key,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true',
      },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const err = await res.text();
      throw new Error('AI 요약 실패: ' + err.slice(0, 140));
    }
    const j = await res.json();
    return j.content?.[0]?.text || '';
  },

  // Fallback summary when no key — a static reflective teaser
  fallback(day) {
    return `오늘은 ${day.ref} 말씀을 묵상합니다.\n\n· 본문을 천천히 두 번 읽어보세요.\n· 마음에 머무는 한 절을 골라보세요.\n· 그 말씀이 오늘 나에게 어떻게 들려오는지 귀 기울여 보세요.\n\n(AI 요약을 사용하시려면 설정에서 Anthropic API 키를 등록해 주세요.)`;
  },
};
