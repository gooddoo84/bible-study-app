const { useState, useEffect, useRef, useMemo } = React;

/* ─── Checkbox + CheckRow ─── */
function Checkbox({ v }) {
  return <div style={{ width: 20, height: 20, borderRadius: 10, background: v ? 'var(--gold)' : 'transparent', border: v ? 'none' : '1.5px solid var(--line-2)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{v && Icon.check(12, '#fff')}</div>;
}
function CheckRow({ v, onChange, label, onOpen }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', padding: '6px 0', gap: 10 }}>
      <div onClick={() => onChange(!v)} style={{ display: 'flex', alignItems: 'center', gap: 10, flex: 1, cursor: 'pointer' }}>
        <Checkbox v={v}/>
        <div style={{ fontSize: 12.5, color: 'var(--ink-2)' }}>{label}</div>
      </div>
      <button onClick={onOpen} style={{ background: 'none', border: 'none', color: 'var(--gold-deep)', fontSize: 11.5, fontWeight: 600, cursor: 'pointer', textDecoration: 'underline', textUnderlineOffset: 2 }}>보기</button>
    </div>
  );
}

/* ─── Auth ─── */
function AuthScreen({ onAuth, onLegal }) {
  const [mode, setMode] = useState('login');
  const [f, setF] = useState({ username: '', password: '', name: '', phone: '' });
  const [err, setErr] = useState('');
  const [agT, setAgT] = useState(false);
  const [agP, setAgP] = useState(false);
  const [loading, setLoading] = useState(false);
  const set = (k) => (e) => setF(x => ({ ...x, [k]: e.target.value }));
  const agreeAll = agT && agP;
  const toggleAll = () => { const v = !agreeAll; setAgT(v); setAgP(v); };

  const submit = async () => {
    setErr(''); setLoading(true);
    try {
      if (mode === 'signup') {
        if (!f.username || !f.password || !f.name || !f.phone) throw new Error('모든 항목을 입력해 주세요.');
        if (f.password.length < 4) throw new Error('비밀번호는 4자 이상이어야 합니다.');
        if (!agT || !agP) throw new Error('이용약관과 개인정보 처리방침에 동의해 주세요.');
        await FB.signUp(f);
      } else {
        if (!f.username || !f.password) throw new Error('아이디와 비밀번호를 입력해 주세요.');
        await FB.signIn({ username: f.username, password: f.password });
      }
      onAuth(FB.currentUser());
    } catch (e) { setErr(e.message); }
    setLoading(false);
  };

  return (
    <div className="cream-bg" style={{ minHeight: '100%', padding: '60px 28px 40px', boxSizing: 'border-box' }}>
      <div style={{ marginBottom: 40, marginTop: 20 }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.16em', color: 'var(--gold-deep)', marginBottom: 10 }}>SEVEN · QT</div>
        <div className="serif" style={{ fontSize: 30, fontWeight: 700, color: 'var(--ink)', lineHeight: 1.3, letterSpacing: '-0.02em' }}>말씀 앞에<br/>고요히 머무는 시간</div>
        <div style={{ fontSize: 13, color: 'var(--ink-muted)', marginTop: 10 }}>매일 한 장씩, 7분법으로 묵상합니다.</div>
      </div>
      <div style={{ display: 'flex', gap: 4, background: 'rgba(58,53,48,0.06)', padding: 4, borderRadius: 14, marginBottom: 22 }}>
        {[['login','로그인'],['signup','회원가입']].map(([id,lbl]) => (
          <button key={id} onClick={() => setMode(id)} style={{ flex: 1, padding: '10px 0', border: 'none', borderRadius: 10, background: mode === id ? '#fff' : 'transparent', color: mode === id ? 'var(--ink)' : 'var(--ink-muted)', fontWeight: 700, fontSize: 13.5, cursor: 'pointer', boxShadow: mode === id ? '0 2px 6px rgba(43,38,32,0.08)' : 'none' }}>{lbl}</button>
        ))}
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {mode === 'signup' && (<>
          <div><div className="label">이름</div><input className="input" value={f.name} onChange={set('name')} placeholder="홍길동"/></div>
          <div><div className="label">전화번호</div><input className="input" value={f.phone} onChange={set('phone')} placeholder="010-1234-5678" inputMode="tel"/></div>
        </>)}
        <div><div className="label">아이디</div><input className="input" value={f.username} onChange={set('username')} placeholder="영문 또는 숫자"/></div>
        <div><div className="label">비밀번호</div><input className="input" value={f.password} onChange={set('password')} type="password" placeholder="4자 이상"/></div>
        {mode === 'signup' && (
          <div style={{ marginTop: 6, padding: '14px 16px', borderRadius: 14, background: 'rgba(255,255,255,0.55)', border: '0.5px solid var(--line-2)' }}>
            <div onClick={toggleAll} style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', fontWeight: 700, fontSize: 13.5, color: 'var(--ink)' }}><Checkbox v={agreeAll}/> 전체 동의</div>
            <div style={{ height: 1, background: 'var(--line-2)', margin: '10px 0' }}/>
            <CheckRow v={agT} onChange={setAgT} label="이용약관 동의 (필수)" onOpen={() => onLegal('terms')}/>
            <CheckRow v={agP} onChange={setAgP} label="개인정보 처리방침 동의 (필수)" onOpen={() => onLegal('privacy')}/>
          </div>
        )}
        {err && <div className="error-banner">{err}</div>}
        <button onClick={submit} className="btn-primary" disabled={loading} style={{ marginTop: 8 }}>{loading ? '잠시만요…' : mode === 'login' ? '로그인' : '회원가입'}</button>
        <div style={{ textAlign: 'center', fontSize: 11, color: 'var(--ink-muted)', marginTop: 8, lineHeight: 1.7 }}>
          {FB.enabled ? '✓ 서버 연결됨' : '⚠ 서버 미연결 — 나눔은 이 기기에만 저장'}<br/>
          회원 정보는 현재 기기에만 저장됩니다
        </div>
      </div>
    </div>
  );
}

/* ─── Legal overlay ─── */
function LegalPage({ kind, onClose }) {
  const title = kind === 'terms' ? '이용약관' : '개인정보 처리방침';
  const content = kind === 'terms' ? TERMS_TEXT : PRIVACY_TEXT;
  return (
    <div style={{ position: 'absolute', inset: 0, background: 'var(--cream)', zIndex: 500, display: 'flex', flexDirection: 'column' }}>
      <StatusBar/>
      <div style={{ padding: '8px 20px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <button onClick={onClose} className="press" style={{ width: 36, height: 36, borderRadius: 18, border: 'none', background: 'rgba(255,255,255,0.7)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{Icon.chevL(14, 'var(--ink-2)')}</button>
        <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--ink)' }}>{title}</div>
        <div style={{ width: 36 }}/>
      </div>
      <div style={{ padding: '8px 24px 40px', overflowY: 'auto', flex: 1 }} className="no-scrollbar">
        <div style={{ whiteSpace: 'pre-wrap', fontSize: 13, lineHeight: 1.85, color: 'var(--ink-2)' }}>{content}</div>
      </div>
      <HomeIndicator/>
    </div>
  );
}

/* ─── Home ─── */
function HomeScreen({ user, onStart, onRead, onTab }) {
  const dayIdx = Store.todayDayIndex();
  const day = BIBLE.getDay(dayIdx);
  const entry = Store.getEntry(dayIdx);
  const doneCount = Object.values(entry.steps || {}).filter(Boolean).length;
  const progress = doneCount / 7;
  const streak = Store.streak();
  const [aiText, setAiText] = useState(localStorage.getItem('mk_ai_' + dayIdx) || '');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiErr, setAiErr] = useState('');

  const genAi = async () => {
    setAiErr(''); setAiLoading(true);
    try {
      const text = await AI.summarize(day.ref, day.verses);
      setAiText(text);
      localStorage.setItem('mk_ai_' + dayIdx, text);
    } catch (e) { setAiErr(e.message); }
    setAiLoading(false);
  };

  return (
    <div className="cream-bg tab-pad" style={{ minHeight: '100%' }}>
      <StatusBar/>
      <div style={{ padding: '10px 24px 24px' }}>
        {/* Greeting */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 24 }}>
          <div>
            <div style={{ fontSize: 12, color: 'var(--ink-muted)', fontWeight: 600 }}>{fmtDate()}</div>
            <div style={{ fontSize: 22, fontWeight: 700, color: 'var(--ink)', marginTop: 4, letterSpacing: '-0.02em' }}>안녕하세요, <span style={{ color: 'var(--gold-deep)' }}>{user.name}</span>님</div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '6px 10px', borderRadius: 12, background: 'rgba(201,169,97,0.18)', color: 'var(--gold-deep)', fontSize: 12, fontWeight: 700 }}>
            {Icon.flame(13, 'var(--gold-deep)')} {streak}일
          </div>
        </div>

        {/* Hero today */}
        <div style={{ position: 'relative', background: 'linear-gradient(160deg,#3A3530 0%,#2B2620 100%)', borderRadius: 26, padding: '22px 22px 24px', color: '#F5E8C8', marginBottom: 16, boxShadow: '0 14px 32px rgba(43,38,32,0.22)' }}>
          <div style={{ fontSize: 10.5, fontWeight: 700, letterSpacing: '0.2em', color: '#C9A961', marginBottom: 10 }}>오늘의 말씀 · DAY {day.day}</div>
          <div className="serif" style={{ fontSize: 22, fontWeight: 700, lineHeight: 1.35, marginBottom: 12, letterSpacing: '-0.01em' }}>{day.ref}</div>
          <div className="serif" style={{ fontSize: 13.5, lineHeight: 1.75, opacity: 0.85, fontStyle: 'italic' }}>
            {day.keyVerse ? `"${day.keyVerse.t}" — ${day.ref} ${day.keyVerse.n}절` : day.title}
          </div>
          <div style={{ display: 'flex', gap: 10, marginTop: 18 }}>
            <button onClick={onRead} style={{ flex: 1, padding: '12px 14px', borderRadius: 16, border: '1px solid rgba(245,232,200,0.2)', background: 'rgba(245,232,200,0.08)', color: '#F5E8C8', fontWeight: 600, fontSize: 13, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>{Icon.book(15,'#F5E8C8')} 본문 읽기</button>
            <button onClick={onStart} style={{ flex: 1, padding: '12px 14px', borderRadius: 16, border: 'none', background: '#C9A961', color: '#2B2620', fontWeight: 700, fontSize: 13, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>{Icon.play(13,'#2B2620')} 묵상 시작</button>
          </div>
        </div>

        {/* AI summary card */}
        <div className="card" style={{ marginBottom: 16, background: 'linear-gradient(135deg,rgba(255,255,255,0.85),rgba(245,232,200,0.45))' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
            {Icon.ai(16, 'var(--gold-deep)')}
            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--gold-deep)', letterSpacing: '0.06em', whiteSpace: 'nowrap' }}>AI 묵상 요약</div>
            {!aiText && !aiLoading && <button onClick={genAi} className="press" style={{ marginLeft: 'auto', padding: '5px 10px', borderRadius: 10, border: '1px solid var(--line-2)', background: 'rgba(255,255,255,0.6)', fontSize: 11, fontWeight: 700, color: 'var(--ink-2)', cursor: 'pointer' }}>생성</button>}
            {aiText && <button onClick={genAi} className="press" style={{ marginLeft: 'auto', padding: '5px 10px', borderRadius: 10, border: 'none', background: 'transparent', fontSize: 11, fontWeight: 600, color: 'var(--gold-deep)', cursor: 'pointer' }}>다시</button>}
          </div>
          {aiLoading && <div style={{ fontSize: 13, color: 'var(--ink-muted)', padding: '12px 0' }}>· · · 묵상을 준비하고 있어요</div>}
          {aiErr && <div className="error-banner" style={{ marginTop: 4 }}>{aiErr}</div>}
          {aiText && <div style={{ fontSize: 13.5, lineHeight: 1.75, color: 'var(--ink-2)', whiteSpace: 'pre-wrap' }}>{aiText}</div>}
          {!aiText && !aiLoading && !aiErr && <div style={{ fontSize: 12.5, lineHeight: 1.7, color: 'var(--ink-muted)' }}>{AI.fallback(day)}</div>}
        </div>

        {/* Progress */}
        <div className="card" style={{ marginBottom: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <Ring progress={progress} size={56} stroke={4.5}>
              <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ink)' }}>{doneCount}/7</div>
            </Ring>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ink)' }}>오늘의 7분법</div>
              <div style={{ fontSize: 12, color: 'var(--ink-muted)', marginTop: 2 }}>
                {doneCount === 0 ? '아직 시작 전' : doneCount === 7 ? '오늘 묵상 완료!' : `${7 - doneCount}단계 남음`}
              </div>
            </div>
            <button onClick={onStart} className="press" style={{ padding: '8px 14px', borderRadius: 14, border: 'none', background: 'var(--ink)', color: '#F5E8C8', fontSize: 12, fontWeight: 700, cursor: 'pointer' }}>{doneCount > 0 ? '이어서' : '시작'}</button>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 4, marginTop: 14 }}>
            {SEVEN_STEPS.map(s => (
              <div key={s.id} style={{ aspectRatio: '1', borderRadius: 10, background: entry.steps?.[s.id] ? s.color : 'rgba(58,53,48,0.06)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, color: entry.steps?.[s.id] ? '#fff' : 'var(--ink-muted)' }}>{s.num}</div>
            ))}
          </div>
        </div>

        {/* Last 7 days */}
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10, padding: '0 2px' }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ink)', whiteSpace: 'nowrap' }}>최근 7일</div>
          <button onClick={() => onTab('stats')} style={{ background: 'none', border: 'none', fontSize: 12, fontWeight: 600, color: 'var(--gold-deep)', cursor: 'pointer' }}>더보기</button>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 6, marginBottom: 20 }}>
          {Store.last7().map((d, i) => (
            <div key={i} style={{ aspectRatio: '0.75', borderRadius: 12, background: d.done ? 'var(--gold)' : d.partial ? 'rgba(201,169,97,0.3)' : 'rgba(58,53,48,0.05)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{d.done && Icon.check(14, '#fff')}</div>
          ))}
        </div>
      </div>
      <HomeIndicator/>
    </div>
  );
}

/* ─── Read screen ─── */
function ReadScreen({ day, onBack, onStart }) {
  const [fontSize, setFontSize] = useState(17);
  return (
    <div className="paper-bg tab-pad" style={{ minHeight: '100%', position: 'relative' }}>
      <StatusBar/>
      <div style={{ padding: '4px 20px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <button onClick={onBack} className="press" style={{ width: 36, height: 36, borderRadius: 18, border: 'none', background: 'rgba(255,255,255,0.7)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{Icon.chevL(14,'var(--ink-2)')}</button>
        <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--gold-deep)', letterSpacing: '0.12em' }}>DAY {day.day} · {day.ref}</div>
        <div style={{ display: 'flex', gap: 4 }}>
          <button onClick={() => setFontSize(Math.max(14, fontSize - 1))} className="press" style={{ width: 30, height: 30, borderRadius: 15, border: 'none', background: 'rgba(255,255,255,0.7)', cursor: 'pointer', fontSize: 13, fontWeight: 700, color: 'var(--ink-2)' }}>A-</button>
          <button onClick={() => setFontSize(Math.min(22, fontSize + 1))} className="press" style={{ width: 30, height: 30, borderRadius: 15, border: 'none', background: 'rgba(255,255,255,0.7)', cursor: 'pointer', fontSize: 13, fontWeight: 700, color: 'var(--ink-2)' }}>A+</button>
        </div>
      </div>
      <div style={{ padding: '8px 26px 110px' }}>
        <div className="serif" style={{ fontSize: 24, fontWeight: 700, color: 'var(--ink)', marginBottom: 6 }}>{day.ref}</div>
        <div style={{ fontSize: 13, color: 'var(--ink-muted)', marginBottom: 22 }}>{day.title}</div>
        {day.stub && <div className="error-banner" style={{ marginBottom: 16 }}>이 장은 아직 본문이 추가되지 않았습니다. <code>data/bible.js</code>에 입력하세요.</div>}
        <div className="serif" style={{ fontSize, lineHeight: 1.95, color: 'var(--ink-2)' }}>
          {day.verses.map(v => (
            <span key={v.n}>
              <span style={{ fontFamily: 'Pretendard,sans-serif', fontSize: 10, fontWeight: 700, color: 'var(--gold-deep)', verticalAlign: 'super', marginRight: 4 }}>{v.n}</span>
              {v.t}
              {' '}
            </span>
          ))}
        </div>
      </div>
      <div style={{ position: 'absolute', bottom: 28, left: 20, right: 20, display: 'flex', gap: 8, zIndex: 50 }}>
        <button onClick={onStart} className="btn-primary press" style={{ flex: 1 }}>묵상 시작 →</button>
      </div>
      <HomeIndicator/>
    </div>
  );
}

/* ─── Meditation (7-step) ─── */
function MeditationScreen({ day, onClose, onDone, user }) {
  const dayIdx = day.day - 1;
  const entry = Store.getEntry(dayIdx);
  const [step, setStep] = useState(0);
  const [notes, setNotes] = useState({ ...entry.notes });
  const [sharing, setSharing] = useState(false);

  const S = SEVEN_STEPS[step];
  const progress = (step + (notes[S.id] ? 0.5 : 0)) / SEVEN_STEPS.length;

  useEffect(() => {
    if (notes[S.id] !== undefined) Store.setNote(dayIdx, S.id, notes[S.id] || '');
  }, [notes[S.id]]);

  const markAndNext = () => {
    Store.setStepDone(dayIdx, S.id, !!(notes[S.id] || '').trim());
    if (step < SEVEN_STEPS.length - 1) setStep(step + 1);
    else finish();
  };

  const finish = async () => {
    Store.setStepDone(dayIdx, S.id, !!(notes[S.id] || '').trim());
    // Auto-share step 1 if toggle on
    if (sharing && notes['meditate']?.trim()) {
      try {
        await FB.addPost({ uid: user.uid, name: user.name, dayIndex: dayIdx, ref: day.ref, text: notes['meditate'] });
      } catch (e) { console.warn('share failed', e); }
    }
    onDone();
  };

  return (
    <div style={{ position: 'absolute', inset: 0, background: 'var(--cream)', zIndex: 300, display: 'flex', flexDirection: 'column' }} className="cream-bg">
      <StatusBar/>
      <div style={{ padding: '4px 20px 8px', display: 'flex', alignItems: 'center', gap: 10 }}>
        <button onClick={onClose} className="press" style={{ width: 36, height: 36, borderRadius: 18, border: 'none', background: 'rgba(255,255,255,0.7)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{Icon.x(16,'var(--ink-2)')}</button>
        <div style={{ flex: 1, height: 6, background: 'rgba(58,53,48,0.08)', borderRadius: 3, overflow: 'hidden' }}>
          <div style={{ height: '100%', width: `${progress * 100}%`, background: 'linear-gradient(90deg,var(--gold),var(--clay))', borderRadius: 3, transition: 'width 0.35s cubic-bezier(0.22,1,0.36,1)' }}/>
        </div>
        <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ink-muted)' }}>{step + 1}/7</div>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: '8px 26px 24px' }} className="no-scrollbar step-enter" key={step}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8 }}>
          <div style={{ width: 44, height: 44, borderRadius: 22, background: S.color + '22', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><StepIcon id={S.id} size={22}/></div>
          <div>
            <div style={{ fontSize: 10.5, fontWeight: 700, letterSpacing: '0.14em', color: S.color }}>STEP {S.num}</div>
            <div style={{ fontSize: 20, fontWeight: 700, color: 'var(--ink)', letterSpacing: '-0.02em' }}>{S.name}</div>
          </div>
        </div>
        <div style={{ fontSize: 13.5, color: 'var(--ink-muted)', lineHeight: 1.65, marginBottom: 16 }}>{S.desc}</div>
        <div style={{ padding: 14, borderRadius: 14, background: S.color + '14', borderLeft: `3px solid ${S.color}`, fontSize: 13, lineHeight: 1.7, color: 'var(--ink-2)', marginBottom: 18 }}>
          <div style={{ fontSize: 10.5, fontWeight: 700, color: S.color, letterSpacing: '0.1em', marginBottom: 6 }}>오늘의 질문</div>
          {S.prompt}
        </div>
        {step === 0 && day.keyVerse && (
          <div className="card serif" style={{ fontSize: 14, lineHeight: 1.7, color: 'var(--ink-2)', marginBottom: 14, fontStyle: 'italic', background: 'rgba(255,255,255,0.4)' }}>
            "{day.keyVerse.t}"
            <div style={{ fontSize: 11, color: 'var(--ink-muted)', marginTop: 6, fontStyle: 'normal', fontFamily: 'Pretendard,sans-serif' }}>— {day.ref} {day.keyVerse.n}절</div>
          </div>
        )}
        <textarea className="editor" value={notes[S.id] || ''} onChange={(e) => setNotes(n => ({ ...n, [S.id]: e.target.value }))} placeholder={S.placeholder}/>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 12 }}>
          {S.chips.map(c => <div key={c} style={{ padding: '5px 11px', borderRadius: 12, background: 'rgba(58,53,48,0.06)', fontSize: 11.5, color: 'var(--ink-muted)', fontWeight: 600, whiteSpace: 'nowrap' }}>{c}</div>)}
        </div>
        {step === 0 && (
          <div onClick={() => setSharing(!sharing)} style={{ marginTop: 20, padding: 14, borderRadius: 14, background: 'rgba(255,255,255,0.55)', border: '0.5px solid var(--line-2)', display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer' }}>
            <Checkbox v={sharing}/>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ink)' }}>이 묵상을 나눔에 공개</div>
              <div style={{ fontSize: 11, color: 'var(--ink-muted)', marginTop: 2 }}>1단계 묵상만 공개됩니다 (나머지는 비공개)</div>
            </div>
          </div>
        )}
      </div>
      <div style={{ padding: '12px 20px 24px', borderTop: '0.5px solid var(--line)', display: 'flex', gap: 10, background: 'rgba(245,241,232,0.9)', backdropFilter: 'blur(12px)' }}>
        {step > 0 && <button onClick={() => setStep(step - 1)} className="btn-ghost press" style={{ flex: 0.4 }}>이전</button>}
        <button onClick={markAndNext} className="btn-primary press" style={{ flex: 1 }}>{step === SEVEN_STEPS.length - 1 ? '묵상 마치기' : '다음 단계 →'}</button>
      </div>
      <HomeIndicator/>
    </div>
  );
}

/* ─── Stats ─── */
function StatsScreen({ onTab }) {
  const streak = Store.streak();
  const total = Store.totalDone();
  const today = Store.todayDayIndex();
  const entries = Store.getEntries();
  // 6-week calendar
  const grid = Array.from({ length: 42 }, (_, i) => {
    const idx = today - 41 + i;
    return { idx, done: !!entries[idx]?.completedAt, partial: !entries[idx]?.completedAt && Object.values(entries[idx]?.steps || {}).some(Boolean) };
  });

  return (
    <div className="cream-bg tab-pad" style={{ minHeight: '100%' }}>
      <StatusBar/>
      <div style={{ padding: '10px 24px 24px' }}>
        <div style={{ fontSize: 24, fontWeight: 700, color: 'var(--ink)', marginBottom: 4 }}>나의 성장</div>
        <div style={{ fontSize: 13, color: 'var(--ink-muted)', marginBottom: 22 }}>말씀 앞에 머문 시간들</div>

        <div style={{ display: 'flex', gap: 10, marginBottom: 16 }}>
          <StatCard label="연속 묵상" value={streak} unit="일" color="var(--gold-deep)" icon={Icon.flame}/>
          <StatCard label="누적 묵상" value={total} unit="일" color="var(--clay)" icon={Icon.check}/>
          <StatCard label="여정" value={today + 1} unit="일차" color="var(--sage)" icon={Icon.book}/>
        </div>

        <div className="card" style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ink)', marginBottom: 4 }}>최근 6주</div>
          <div style={{ fontSize: 11, color: 'var(--ink-muted)', marginBottom: 14 }}>각 네모 = 하루</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 5 }}>
            {['일','월','화','수','목','금','토'].map(d => <div key={d} style={{ fontSize: 10, fontWeight: 600, color: 'var(--ink-muted)', textAlign: 'center', paddingBottom: 4 }}>{d}</div>)}
            {grid.map((d, i) => (
              <div key={i} style={{ aspectRatio: '1', borderRadius: 8, background: d.idx < 0 ? 'transparent' : d.done ? 'var(--gold)' : d.partial ? 'rgba(201,169,97,0.3)' : 'rgba(58,53,48,0.05)', border: d.idx === today ? '1.5px solid var(--ink)' : 'none' }}/>
            ))}
          </div>
        </div>

        <div className="card">
          <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ink)', marginBottom: 14 }}>읽기 진도</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <Ring progress={Math.min(1, (today + 1) / 68)} size={72} stroke={6}>
              <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ink)' }}>{Math.round(((today + 1) / 68) * 100)}%</div>
            </Ring>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ink)' }}>마가→마태→누가</div>
              <div style={{ fontSize: 12, color: 'var(--ink-muted)', marginTop: 4, lineHeight: 1.6 }}>신약 복음서를 순서대로 매일 한 장씩 읽습니다.</div>
            </div>
          </div>
        </div>
      </div>
      <HomeIndicator/>
    </div>
  );
}
function StatCard({ label, value, unit, color, icon }) {
  return (
    <div style={{ flex: 1, background: 'rgba(255,255,255,0.65)', borderRadius: 18, padding: 14, border: '0.5px solid var(--line-2)' }}>
      <div style={{ width: 28, height: 28, borderRadius: 14, background: color + '1f', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 8 }}>{icon(14, color)}</div>
      <div style={{ fontSize: 11, color: 'var(--ink-muted)', fontWeight: 600, whiteSpace: 'nowrap' }}>{label}</div>
      <div style={{ fontSize: 22, fontWeight: 800, color: 'var(--ink)', marginTop: 2, letterSpacing: '-0.02em' }}>{value}<span style={{ fontSize: 12, color: 'var(--ink-muted)', fontWeight: 600, marginLeft: 2 }}>{unit}</span></div>
    </div>
  );
}

/* ─── Share / Community ─── */
function ShareScreen({ user }) {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [detail, setDetail] = useState(null);
  useEffect(() => { reload(); }, []);
  const reload = async () => { setLoading(true); setPosts(await FB.getPosts()); setLoading(false); };
  const like = async (p) => { await FB.toggleLike(p.id, user.uid); await reload(); };

  return (
    <div className="cream-bg tab-pad" style={{ minHeight: '100%' }}>
      <StatusBar/>
      <div style={{ padding: '10px 24px 24px' }}>
        <div style={{ fontSize: 24, fontWeight: 700, color: 'var(--ink)', marginBottom: 4 }}>함께 나눔</div>
        <div style={{ fontSize: 13, color: 'var(--ink-muted)', marginBottom: 20 }}>{FB.enabled ? '서로의 묵상 1단계를 나눕니다' : '⚠ 현재 이 기기의 나눔만 표시됩니다'}</div>

        {loading && <div style={{ padding: 20, textAlign: 'center', color: 'var(--ink-muted)', fontSize: 13 }}>나눔을 불러오는 중…</div>}
        {!loading && posts.length === 0 && (
          <div className="card" style={{ textAlign: 'center', padding: '32px 20px' }}>
            <div style={{ fontSize: 36, marginBottom: 8 }}>📖</div>
            <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ink)' }}>아직 나눔이 없어요</div>
            <div style={{ fontSize: 12, color: 'var(--ink-muted)', marginTop: 6, lineHeight: 1.6 }}>묵상 1단계에서 "나눔에 공개"를 선택하면 여기에 표시됩니다.</div>
          </div>
        )}
        {!loading && posts.map(p => (
          <div key={p.id} className="card" style={{ marginBottom: 12, cursor: 'pointer' }} onClick={() => setDetail(p)}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
              <div style={{ width: 28, height: 28, borderRadius: 14, background: 'linear-gradient(135deg,var(--gold),var(--clay))', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: 12, fontWeight: 700 }}>{(p.name || '?').charAt(0)}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ink)' }}>{p.name}</div>
                <div style={{ fontSize: 11, color: 'var(--ink-muted)' }}>{p.ref} · {timeAgo(p.createdAt)}</div>
              </div>
            </div>
            <div className="serif" style={{ fontSize: 14, lineHeight: 1.7, color: 'var(--ink-2)', marginBottom: 12, maxHeight: 100, overflow: 'hidden', position: 'relative' }}>
              {p.text.slice(0, 200)}{p.text.length > 200 && '…'}
            </div>
            <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
              <button onClick={(e) => { e.stopPropagation(); like(p); }} style={{ background: 'none', border: 'none', display: 'flex', alignItems: 'center', gap: 5, color: (p.likes || []).includes(user.uid) ? 'var(--clay)' : 'var(--ink-muted)', fontSize: 12, fontWeight: 600, cursor: 'pointer', padding: 0 }}>
                {Icon.heart(15, (p.likes || []).includes(user.uid) ? 'var(--clay)' : 'var(--ink-muted)', (p.likes || []).includes(user.uid) ? 'var(--clay)' : 'none')}
                {(p.likes || []).length}
              </button>
              <div style={{ display: 'flex', alignItems: 'center', gap: 5, color: 'var(--ink-muted)', fontSize: 12, fontWeight: 600 }}>{Icon.message(14, 'var(--ink-muted)')}{p.commentCount || 0}</div>
            </div>
          </div>
        ))}
      </div>
      {detail && <PostDetail post={detail} user={user} onClose={() => { setDetail(null); reload(); }}/>}
      <HomeIndicator/>
    </div>
  );
}

function PostDetail({ post, user, onClose }) {
  const [comments, setComments] = useState([]);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(true);
  useEffect(() => { load(); }, []);
  const load = async () => { setLoading(true); setComments(await FB.getComments(post.id)); setLoading(false); };
  const send = async () => {
    if (!text.trim()) return;
    await FB.addComment(post.id, { uid: user.uid, name: user.name, text: text.trim() });
    setText(''); load();
  };
  return (
    <div style={{ position: 'absolute', inset: 0, background: 'var(--cream)', zIndex: 400, display: 'flex', flexDirection: 'column' }} className="cream-bg">
      <StatusBar/>
      <div style={{ padding: '4px 20px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <button onClick={onClose} className="press" style={{ width: 36, height: 36, borderRadius: 18, border: 'none', background: 'rgba(255,255,255,0.7)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{Icon.chevL(14,'var(--ink-2)')}</button>
        <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ink)' }}>나눔</div>
        <div style={{ width: 36 }}/>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: '0 24px 16px' }} className="no-scrollbar">
        <div className="card" style={{ marginBottom: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
            <div style={{ width: 32, height: 32, borderRadius: 16, background: 'linear-gradient(135deg,var(--gold),var(--clay))', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: 13, fontWeight: 700 }}>{(post.name || '?').charAt(0)}</div>
            <div>
              <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ink)' }}>{post.name}</div>
              <div style={{ fontSize: 11, color: 'var(--ink-muted)' }}>{post.ref} · {timeAgo(post.createdAt)}</div>
            </div>
          </div>
          <div className="serif" style={{ fontSize: 15, lineHeight: 1.8, color: 'var(--ink-2)', whiteSpace: 'pre-wrap' }}>{post.text}</div>
        </div>
        <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ink)', marginBottom: 10 }}>댓글 {comments.length}</div>
        {loading && <div style={{ fontSize: 12, color: 'var(--ink-muted)' }}>불러오는 중…</div>}
        {!loading && comments.length === 0 && <div style={{ fontSize: 12, color: 'var(--ink-muted)', padding: '14px 0' }}>첫 댓글을 남겨 보세요.</div>}
        {comments.map(c => (
          <div key={c.id} style={{ padding: '12px 0', borderBottom: '0.5px solid var(--line)' }}>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 4 }}>
              <div style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--ink)' }}>{c.name}</div>
              <div style={{ fontSize: 11, color: 'var(--ink-muted)' }}>{timeAgo(c.createdAt)}</div>
            </div>
            <div style={{ fontSize: 13, lineHeight: 1.65, color: 'var(--ink-2)' }}>{c.text}</div>
          </div>
        ))}
      </div>
      <div style={{ padding: '10px 16px 24px', borderTop: '0.5px solid var(--line)', background: 'rgba(245,241,232,0.9)', display: 'flex', gap: 8 }}>
        <input className="input" value={text} onChange={(e) => setText(e.target.value)} placeholder="따뜻한 한마디를 남겨주세요" onKeyDown={(e) => e.key === 'Enter' && send()}/>
        <button onClick={send} className="press" style={{ padding: '0 16px', borderRadius: 14, border: 'none', background: 'var(--ink)', color: '#F5E8C8', fontSize: 13, fontWeight: 700, cursor: 'pointer' }}>등록</button>
      </div>
      <HomeIndicator/>
    </div>
  );
}

function timeAgo(ts) {
  const s = (Date.now() - ts) / 1000;
  if (s < 60) return '방금 전';
  if (s < 3600) return `${Math.floor(s / 60)}분 전`;
  if (s < 86400) return `${Math.floor(s / 3600)}시간 전`;
  if (s < 86400 * 7) return `${Math.floor(s / 86400)}일 전`;
  return new Date(ts).toLocaleDateString('ko-KR');
}

/* ─── Settings ─── */
function SettingsScreen({ user, onLogout, onLegal }) {
  const [apiKey, setApiKey] = useState(AI.getKey());
  const [saved, setSaved] = useState(false);
  const save = () => { AI.setKey(apiKey); setSaved(true); setTimeout(() => setSaved(false), 1500); };

  return (
    <div className="cream-bg tab-pad" style={{ minHeight: '100%' }}>
      <StatusBar/>
      <div style={{ padding: '10px 24px 24px' }}>
        <div style={{ fontSize: 24, fontWeight: 700, color: 'var(--ink)', marginBottom: 4 }}>설정</div>
        <div style={{ fontSize: 13, color: 'var(--ink-muted)', marginBottom: 22 }}>계정 · AI · 약관</div>

        {/* Profile */}
        <div className="card" style={{ marginBottom: 16, display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 48, height: 48, borderRadius: 24, background: 'linear-gradient(135deg,var(--gold),var(--clay))', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: 18, fontWeight: 700 }}>{(user.name || '?').charAt(0)}</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--ink)' }}>{user.name}</div>
            <div style={{ fontSize: 12, color: 'var(--ink-muted)', marginTop: 2 }}>@{user.username}</div>
          </div>
        </div>

        {/* AI */}
        <div className="card" style={{ marginBottom: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
            {Icon.ai(18, 'var(--gold-deep)')}
            <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ink)', whiteSpace: 'nowrap' }}>AI 묵상 요약</div>
          </div>
          <div style={{ fontSize: 12, color: 'var(--ink-muted)', lineHeight: 1.65, marginBottom: 12 }}>Anthropic Claude API 키를 등록하면 매일 본문의 AI 요약을 볼 수 있습니다. 키는 이 기기에만 저장되며 요청은 이용자의 계정으로 직접 호출됩니다.</div>
          <input className="input" value={apiKey} onChange={(e) => setApiKey(e.target.value)} placeholder="sk-ant-..." type="password" style={{ marginBottom: 10, fontFamily: 'ui-monospace,monospace', fontSize: 12.5 }}/>
          <button onClick={save} className="btn-primary press" style={{ fontSize: 13 }}>{saved ? '저장됨 ✓' : '저장'}</button>
          <div style={{ fontSize: 11, color: 'var(--ink-muted)', marginTop: 8, lineHeight: 1.6 }}>
            키 발급: <span style={{ color: 'var(--gold-deep)' }}>console.anthropic.com</span> → API Keys
          </div>
        </div>

        {/* Backend status */}
        <div className="card" style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ink)', marginBottom: 6 }}>백엔드 상태</div>
          <div style={{ fontSize: 12, color: 'var(--ink-muted)', lineHeight: 1.7 }}>
            나눔 저장: <strong style={{ color: FB.enabled ? 'var(--sage)' : 'var(--clay)' }}>{FB.enabled ? 'Firebase 연결됨' : '로컬 저장 (기기)'}</strong><br/>
            {!FB.enabled && <span>README를 참고해 <code>firebase-config.js</code>를 설정하면 서로 간 나눔이 가능합니다.</span>}
          </div>
        </div>

        {/* Legal */}
        <div className="card" style={{ marginBottom: 16, padding: 0, overflow: 'hidden' }}>
          <MenuRow icon={Icon.doc} label="이용약관" onClick={() => onLegal('terms')}/>
          <div style={{ height: 0.5, background: 'var(--line)' }}/>
          <MenuRow icon={Icon.doc} label="개인정보 처리방침" onClick={() => onLegal('privacy')}/>
        </div>

        <button onClick={onLogout} className="btn-ghost press" style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
          {Icon.logout(16, 'var(--ink-2)')} 로그아웃
        </button>

        <div style={{ textAlign: 'center', fontSize: 10.5, color: 'var(--ink-muted)', marginTop: 24, lineHeight: 1.7 }}>
          말씀묵상 · 7분법 QT<br/>
          본문: 개역한글 (공공도메인)<br/>
          Day {Store.todayDayIndex() + 1} · 설치: {Store.getInstallDate().toLocaleDateString('ko-KR')}
        </div>
      </div>
      <HomeIndicator/>
    </div>
  );
}
function MenuRow({ icon, label, onClick }) {
  return (
    <div onClick={onClick} style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }}>
      {icon(16, 'var(--ink-2)')}
      <div style={{ flex: 1, fontSize: 14, color: 'var(--ink)', fontWeight: 600 }}>{label}</div>
      {Icon.chevR(14, 'var(--ink-muted)')}
    </div>
  );
}

/* ─── Main App ─── */
function App() {
  const [user, setUser] = useState(FB.currentUser());
  const [tab, setTab] = useState('home');
  const [mode, setMode] = useState('tab'); // tab | read | meditate
  const [legal, setLegal] = useState(null);
  const [rev, setRev] = useState(0); // bumps to force re-render after saves
  const dayIdx = Store.todayDayIndex();
  const day = BIBLE.getDay(dayIdx);

  if (!user) return (
    <div className="stage">
      <div className="frame-shell" data-screen-label="iPhone">
        <div className="notch"/>
        <div className="frame-inner">
          <AuthScreen onAuth={setUser} onLegal={setLegal}/>
          {legal && <LegalPage kind={legal} onClose={() => setLegal(null)}/>}
        </div>
      </div>
    </div>
  );

  const screens = {
    home: <HomeScreen key={rev} user={user} onStart={() => setMode('meditate')} onRead={() => setMode('read')} onTab={setTab}/>,
    read: <ReadScreen day={day} onBack={() => setTab('home')} onStart={() => setMode('meditate')}/>,
    stats: <StatsScreen key={rev} onTab={setTab}/>,
    share: <ShareScreen user={user}/>,
    settings: <SettingsScreen user={user} onLogout={() => { FB.signOut(); setUser(null); }} onLegal={setLegal}/>,
  };

  return (
    <div className="stage">
      <div className="frame-shell" data-screen-label="iPhone">
        <div className="notch"/>
        <div className="frame-inner">
          {mode === 'tab' && (
            <>
              <div className="screen-scroll no-scrollbar">{screens[tab]}</div>
              <TabBar active={tab} onChange={(t) => { setTab(t); setMode('tab'); }}/>
            </>
          )}
          {mode === 'read' && <ReadScreen day={day} onBack={() => setMode('tab')} onStart={() => setMode('meditate')}/>}
          {mode === 'meditate' && <MeditationScreen day={day} user={user} onClose={() => setMode('tab')} onDone={() => { setMode('tab'); setRev(r => r + 1); }}/>}
          {legal && <LegalPage kind={legal} onClose={() => setLegal(null)}/>}
        </div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
