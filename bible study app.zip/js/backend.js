// Firebase + Auth helpers with localStorage fallback
(function initFirebase() {
  const cfg = window.FIREBASE_CONFIG;
  const ok = cfg && cfg.apiKey && cfg.projectId && !String(cfg.apiKey).startsWith('YOUR_');

  window.FB = {
    enabled: false,

    async signUp({ username, password, name, phone }) {
      const users = JSON.parse(localStorage.getItem('mk_users') || '[]');
      if (users.find(u => u.username === username)) throw new Error('이미 사용 중인 아이디입니다.');
      const user = { uid: 'u_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8), username, password, name, phone, joinedAt: Date.now() };
      users.push(user);
      localStorage.setItem('mk_users', JSON.stringify(users));
      localStorage.setItem('mk_session', JSON.stringify({ uid: user.uid, name: user.name, username: user.username }));
      return user;
    },

    async signIn({ username, password }) {
      const users = JSON.parse(localStorage.getItem('mk_users') || '[]');
      const u = users.find(x => x.username === username && x.password === password);
      if (!u) throw new Error('아이디 또는 비밀번호가 올바르지 않습니다.');
      localStorage.setItem('mk_session', JSON.stringify({ uid: u.uid, name: u.name, username: u.username }));
      return u;
    },

    signOut() { localStorage.removeItem('mk_session'); },
    currentUser() { try { return JSON.parse(localStorage.getItem('mk_session') || 'null'); } catch { return null; } },

    async getPosts() {
      if (this.enabled && this._db) {
        const snap = await this._db.collection('posts').orderBy('createdAt', 'desc').limit(100).get();
        return snap.docs.map(d => ({ id: d.id, ...d.data() }));
      }
      return JSON.parse(localStorage.getItem('mk_posts') || '[]').sort((a, b) => b.createdAt - a.createdAt);
    },

    async addPost(post) {
      const doc = { ...post, createdAt: Date.now(), likes: [], commentCount: 0 };
      if (this.enabled && this._db) {
        const ref = await this._db.collection('posts').add(doc);
        return { id: ref.id, ...doc };
      }
      doc.id = 'p_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
      const posts = JSON.parse(localStorage.getItem('mk_posts') || '[]');
      posts.push(doc);
      localStorage.setItem('mk_posts', JSON.stringify(posts));
      return doc;
    },

    async toggleLike(postId, uid) {
      if (this.enabled && this._db) {
        const ref = this._db.collection('posts').doc(postId);
        const snap = await ref.get();
        const likes = snap.data().likes || [];
        const i = likes.indexOf(uid);
        if (i >= 0) likes.splice(i, 1); else likes.push(uid);
        await ref.update({ likes });
        return;
      }
      const posts = JSON.parse(localStorage.getItem('mk_posts') || '[]');
      const p = posts.find(x => x.id === postId); if (!p) return;
      p.likes = p.likes || [];
      const i = p.likes.indexOf(uid);
      if (i >= 0) p.likes.splice(i, 1); else p.likes.push(uid);
      localStorage.setItem('mk_posts', JSON.stringify(posts));
    },

    async getComments(postId) {
      if (this.enabled && this._db) {
        const snap = await this._db.collection('posts').doc(postId).collection('comments').orderBy('createdAt', 'asc').get();
        return snap.docs.map(d => ({ id: d.id, ...d.data() }));
      }
      const all = JSON.parse(localStorage.getItem('mk_comments') || '{}');
      return (all[postId] || []).sort((a, b) => a.createdAt - b.createdAt);
    },

    async addComment(postId, comment) {
      const doc = { ...comment, createdAt: Date.now() };
      if (this.enabled && this._db) {
        const ref = await this._db.collection('posts').doc(postId).collection('comments').add(doc);
        await this._db.collection('posts').doc(postId).update({ commentCount: firebase.firestore.FieldValue.increment(1) });
        return { id: ref.id, ...doc };
      }
      doc.id = 'c_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
      const all = JSON.parse(localStorage.getItem('mk_comments') || '{}');
      all[postId] = all[postId] || [];
      all[postId].push(doc);
      localStorage.setItem('mk_comments', JSON.stringify(all));
      const posts = JSON.parse(localStorage.getItem('mk_posts') || '[]');
      const p = posts.find(x => x.id === postId);
      if (p) { p.commentCount = (p.commentCount || 0) + 1; localStorage.setItem('mk_posts', JSON.stringify(posts)); }
      return doc;
    },
  };

  if (ok && typeof firebase !== 'undefined') {
    try {
      firebase.initializeApp(cfg);
      window.FB._fb = firebase;
      window.FB._db = firebase.firestore();
      window.FB.enabled = true;
      console.log('[Firebase] ✓ Connected to', cfg.projectId);
    } catch (e) {
      console.warn('[Firebase] init failed:', e.message);
    }
  } else {
    console.log('[Firebase] not configured — using localStorage.');
  }
})();
