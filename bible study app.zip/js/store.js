// Progress + data store (localStorage)
// - Entries keyed by dayIndex (0-based). Each entry has notes per step, completed flags, createdAt.
// - streak computed from entry completedAt dates.

window.Store = {
  installKey: 'mk_install_at',
  entriesKey: 'mk_entries',

  getInstallDate() {
    let t = localStorage.getItem(this.installKey);
    if (!t) { t = String(Date.now()); localStorage.setItem(this.installKey, t); }
    return new Date(parseInt(t, 10));
  },

  // Day 1 = install date. dayIndex(today) = floor((today - installDate) / 86400000)
  todayDayIndex() {
    const install = this.getInstallDate();
    const a = new Date(install.getFullYear(), install.getMonth(), install.getDate());
    const now = new Date();
    const b = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    return Math.floor((b - a) / 86400000);
  },

  getEntries() {
    try { return JSON.parse(localStorage.getItem(this.entriesKey) || '{}'); } catch { return {}; }
  },
  saveEntries(e) { localStorage.setItem(this.entriesKey, JSON.stringify(e)); },

  getEntry(dayIndex) {
    const e = this.getEntries();
    return e[dayIndex] || { notes: {}, steps: {}, completedAt: null };
  },

  updateEntry(dayIndex, patch) {
    const e = this.getEntries();
    e[dayIndex] = { ...(e[dayIndex] || { notes: {}, steps: {} }), ...patch };
    this.saveEntries(e);
    return e[dayIndex];
  },

  setNote(dayIndex, stepId, text) {
    const e = this.getEntries();
    e[dayIndex] = e[dayIndex] || { notes: {}, steps: {}, completedAt: null };
    e[dayIndex].notes[stepId] = text;
    this.saveEntries(e);
  },

  setStepDone(dayIndex, stepId, done) {
    const e = this.getEntries();
    e[dayIndex] = e[dayIndex] || { notes: {}, steps: {}, completedAt: null };
    e[dayIndex].steps[stepId] = !!done;
    // Completion: all 7 steps done (share optional — we'll mark as complete when first 6 done)
    const required = SEVEN_STEPS.slice(0, 6).map(s => s.id);
    const allDone = required.every(id => e[dayIndex].steps[id]);
    if (allDone && !e[dayIndex].completedAt) e[dayIndex].completedAt = Date.now();
    this.saveEntries(e);
  },

  // Streak: consecutive completed days ending today
  streak() {
    const entries = this.getEntries();
    const today = this.todayDayIndex();
    let streak = 0;
    for (let i = today; i >= 0; i--) {
      if (entries[i]?.completedAt) streak++;
      else if (i < today) break; // today optional
    }
    return streak;
  },

  totalDone() {
    const entries = this.getEntries();
    return Object.values(entries).filter(e => e.completedAt).length;
  },

  last7() {
    const today = this.todayDayIndex();
    const entries = this.getEntries();
    const arr = [];
    for (let i = 6; i >= 0; i--) {
      const idx = today - i;
      arr.push({
        dayIndex: idx,
        done: !!entries[idx]?.completedAt,
        partial: !entries[idx]?.completedAt && Object.values(entries[idx]?.steps || {}).some(Boolean),
      });
    }
    return arr;
  },
};
