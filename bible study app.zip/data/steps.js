// 7분법 단계 정의 (재정의: 묵상→찬양→감사→회개→간구→중보→특별대상)
window.SEVEN_STEPS = [
  {
    id: 'meditate', num: 1, name: '말씀 묵상',
    desc: '본문을 천천히 읽고 마음에 새기기',
    icon: 'book', color: '#C9A961',
    shared: true, // 이 단계만 나눔에 공개됨
    prompt: '오늘 본문을 두 번 천천히 읽으세요. 마음에 머무는 한 절을 골라, 그 말씀이 오늘 나에게 어떻게 들리는지 적어보세요.',
    placeholder: '오늘 말씀에서 가장 마음에 남은 구절은…\n\n그 말씀이 오늘 나에게 들려주는 소리는…',
    chips: ['마음에 남은 절', '깨달음', '적용'],
  },
  {
    id: 'praise', num: 2, name: '찬양과 경배',
    desc: '하나님의 성품과 영광을 높이기',
    icon: 'sparkle', color: '#B86F3C',
    prompt: '오늘 말씀에서 발견한 하나님의 성품, 크심, 사랑을 높여드리세요. 하나님이 누구신지 고백해 보세요.',
    placeholder: '주님, 주님은…\n\n주님의 (사랑/거룩/능력/지혜)을 찬양합니다…',
    chips: ['하나님의 성품', '위대하심', '아름다움'],
  },
  {
    id: 'thanks', num: 3, name: '감사',
    desc: '받은 은혜를 세어보기',
    icon: 'heart', color: '#D88C4F',
    prompt: '오늘 하루와 지난 시간 속에 하나님이 베푸신 은혜를 구체적으로 떠올려 감사해 보세요.',
    placeholder: '주님, 오늘 이것을 감사합니다…\n\n1.\n2.\n3.',
    chips: ['오늘의 은혜', '관계', '일상'],
  },
  {
    id: 'repent', num: 4, name: '회개',
    desc: '주님 앞에 정직하게 고백하기',
    icon: 'drop', color: '#8F6B8F',
    prompt: '말씀의 빛 앞에서 내 모습을 돌아보세요. 생각과 말과 행실로 지은 죄를 구체적으로 고백하세요.',
    placeholder: '주님, 제가 이 부분에서 주님 뜻과 달랐습니다…',
    chips: ['생각', '말', '행동', '관계'],
  },
  {
    id: 'petition', num: 5, name: '간구',
    desc: '나의 필요를 주님께 아뢰기',
    icon: 'sprout', color: '#6B8273',
    prompt: '오늘 나에게 절실한 필요와 소원을 솔직하게 아뢰세요. 지혜, 힘, 치유, 방향이 필요한 영역은 무엇인가요?',
    placeholder: '주님께 아뢰는 오늘의 간구…',
    chips: ['지혜', '건강', '방향', '관계', '일'],
  },
  {
    id: 'intercede', num: 6, name: '중보기도',
    desc: '타인을 위해 기도하기',
    icon: 'users', color: '#7A9ABC',
    prompt: '가족, 교회, 이웃, 나라, 열방을 위해 기도하세요. 오늘 마음에 특별히 기억나는 사람이 있나요?',
    placeholder: '오늘 중보하는 사람들과 기도제목…\n\n· 가족\n· 교회\n· 이웃\n· 나라와 열방',
    chips: ['가족', '교회', '이웃', '나라', '열방'],
  },
  {
    id: 'special', num: 7, name: '특별대상',
    desc: '오늘 특별히 맡기고 싶은 사람/일',
    icon: 'star', color: '#A67C52',
    prompt: '오늘 특별히 주님께 맡기고 싶은 한 사람이나 한 가지 상황이 있나요? 지속적으로 기도할 대상을 적어두세요.',
    placeholder: '오늘의 특별한 기도 대상…',
    chips: ['이름', '상황', '기간'],
  },
];

// Only step 1 (meditate) is shared publicly
window.SHARED_STEP_ID = 'meditate';
