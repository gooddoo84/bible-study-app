// Bible text — 개역한글 (공공도메인). 마가복음 전장 + 누가복음 일부
// Structure: { book, chapter, title, verses: [{n, t}] }
// Mark 1-16 and Luke stubs. Edit this file to expand.

window.BIBLE = {
  plan: [
    // Day index → { book, chapter }
    ...Array.from({length: 16}, (_, i) => ({ book: 'mark', chapter: i + 1 })),
    ...Array.from({length: 28}, (_, i) => ({ book: 'matthew', chapter: i + 1 })),
    ...Array.from({length: 24}, (_, i) => ({ book: 'luke', chapter: i + 1 })),
  ],
  books: {
    mark: { ko: '마가복음', short: '막', chapters: 16 },
    matthew: { ko: '마태복음', short: '마', chapters: 28 },
    luke: { ko: '누가복음', short: '눅', chapters: 24 },
    john: { ko: '요한복음', short: '요', chapters: 21 },
  },
  chapters: {},
};

// --- 마가복음 1장 ---
window.BIBLE.chapters['mark-1'] = {
  title: '세례 요한이 길을 예비함 · 예수님의 공생애 시작',
  verses: [
    { n: 1, t: '하나님의 아들 예수 그리스도 복음의 시작이라' },
    { n: 2, t: '선지자 이사야의 글에 보라 내가 내 사자를 네 앞에 보내노니 저가 네 길을 예비하리라' },
    { n: 3, t: '광야에 외치는 자의 소리가 있어 가로되 너희는 주의 길을 예비하라 그의 첩경을 평탄케 하라 기록된 것과 같이' },
    { n: 4, t: '세례 요한이 이르러 광야에서 죄 사함을 받게하는 회개의 세례를 전파하니' },
    { n: 5, t: '온 유대 지방과 예루살렘 사람이 다 나아가 자기 죄를 자복하고 요단강에서 그에게 세례를 받더라' },
    { n: 6, t: '요한은 약대털을 입고 허리에 가죽띠를 띠고 메뚜기와 석청을 먹더라' },
    { n: 7, t: '그가 전파하여 가로되 나보다 능력 많으신 이가 내 뒤에 오시나니 나는 그의 신들메를 풀기도 감당치 못하겠노라' },
    { n: 8, t: '나는 너희에게 물로 세례를 주었거니와 그는 성령으로 너희에게 세례를 주시리라' },
    { n: 9, t: '그 때에 예수께서 갈릴리 나사렛으로부터 와서 요단강에서 요한에게 세례를 받으시고' },
    { n: 10, t: '곧 물에서 올라오실새 하늘이 갈라짐과 성령이 비둘기 같이 자기에게 내려오심을 보시더니' },
    { n: 11, t: '하늘로서 소리가 나기를 너는 내 사랑하는 아들이라 내가 너를 기뻐하노라 하시니라' },
    { n: 12, t: '성령이 곧 예수를 광야로 몰아내신지라' },
    { n: 13, t: '광야에서 사십일을 계셔서 사단에게 시험을 받으시며 들짐승과 함께 계시니 천사들이 수종들더라' },
    { n: 14, t: '요한이 잡힌 후 예수께서 갈릴리에 오셔서 하나님의 복음을 전파하여' },
    { n: 15, t: '가라사대 때가 찼고 하나님 나라가 가까왔으니 회개하고 복음을 믿으라 하시더라' },
    { n: 16, t: '갈릴리 해변으로 지나가시다가 시몬과 그 형제 안드레가 바다에 그물 던지는 것을 보고 저희는 어부라' },
    { n: 17, t: '예수께서 가라사대 나를 따라 오너라 내가 너희로 사람을 낚는 어부가 되게 하리라 하시니' },
    { n: 18, t: '곧 그물을 버려 두고 좇으니라' },
    { n: 19, t: '조금 더 가시다가 세베대의 아들 야고보와 그 형제 요한을 보시니 저희도 배에 있어 그물을 깁는데' },
    { n: 20, t: '곧 부르시니 그 아비 세베대를 삯군들과 함께 배에 버려두고 예수를 따라 가니라' },
    { n: 21, t: '저희가 가버나움에 들어가니라 예수께서 곧 안식일에 회당에 들어가 가르치시매' },
    { n: 22, t: '뭇사람이 그의 교훈에 놀라니 이는 그 가르치시는 것이 권세있는 자와 같고 서기관들과 같지 아니함일러라' },
    { n: 23, t: '마침 저희 회당에 더러운 귀신 들린 사람이 있어 소리질러 가로되' },
    { n: 24, t: '나사렛 예수여 우리가 당신과 무슨 상관이 있나이까 우리를 멸하러 왔나이까 나는 당신이 누구인줄 아노니 하나님의 거룩한 자니이다' },
    { n: 25, t: '예수께서 꾸짖어 가라사대 잠잠하고 그 사람에게서 나오라 하시니' },
    { n: 26, t: '더러운 귀신이 그 사람으로 경련을 일으키고 큰소리를 지르며 나오는지라' },
    { n: 27, t: '다 놀라 서로 물어 가로되 이는 어찜이뇨 권세있는 새 교훈이로다 더러운 귀신들을 명한즉 순종하는도다 하더라' },
    { n: 28, t: '예수의 소문이 곧 온 갈릴리 사방에 퍼지더라' },
    { n: 29, t: '회당에서 나와 곧 야고보와 요한과 함께 시몬과 안드레의 집에 들어 가시니' },
    { n: 30, t: '시몬의 장모가 열병으로 누웠는지라 사람들이 곧 그의 일로 예수께 여짜온대' },
    { n: 31, t: '나아가사 그 손을 잡아 일으키시니 열병이 떠나고 여자가 저희에게 수종드니라' },
    { n: 32, t: '저물어 해질 때에 모든 병자와 귀신들린 자를 예수께 데려오니' },
    { n: 33, t: '온 동네가 문 앞에 모였더라' },
    { n: 34, t: '예수께서 각색 병든 많은 사람을 고치시며 많은 귀신을 내어 쫓으시되 귀신이 자기를 알므로 그 말하는 것을 허락지 아니하시니라' },
    { n: 35, t: '새벽 오히려 미명에 예수께서 일어나 나가 한적한 곳으로 가사 거기서 기도하시더니' },
    { n: 36, t: '시몬과 및 그와 함께 있는 자들이 예수의 뒤를 따라가' },
    { n: 37, t: '만나서 가로되 모든 사람이 주를 찾나이다' },
    { n: 38, t: '이르시되 우리가 다른 가까운 마을들로 가자 거기서도 전도하리니 내가 이를 위하여 왔노라 하시고' },
    { n: 39, t: '이에 온 갈릴리에 다니시며 저희 여러 회당에서 전도하시고 또 귀신들을 내어 쫓으시더라' },
    { n: 40, t: '한 문둥병자가 예수께 와서 꿇어 엎드리어 간구하여 가로되 원하시면 저를 깨끗케 하실 수 있나이다' },
    { n: 41, t: '예수께서 민망히 여기사 손을 내밀어 저에게 대시며 가라사대 내가 원하노니 깨끗함을 받으라 하신대' },
    { n: 42, t: '곧 문둥병이 그 사람에게서 떠나가고 깨끗하여진지라' },
    { n: 43, t: '엄히 경계하사 곧 보내시며' },
    { n: 44, t: '가라사대 삼가 아무에게 아무 말도 하지 말고 가서 네 몸을 제사장에게 보이고 네 깨끗케 됨을 인하여 모세의 명한 것을 드려 저희에게 증거하라 하셨더니' },
    { n: 45, t: '그러나 그 사람이 나가서 이 일을 많이 전파하여 널리 퍼지게 하니 그러므로 예수께서 다시는 드러나게 동네에 들어가지 못하시고 오직 바깥 한적한 곳에 계셨으나 사방에서 그에게로 나아오더라' },
  ],
};

// For Mark 2-16, Luke, Matthew — stub chapters with placeholder note.
// In production, fill these in with public-domain 개역한글 text.
// Tool to bulk-populate: scripts/fetch-bible.js (see README)

function stubChapter(book, chapter) {
  const bookKo = window.BIBLE.books[book]?.ko || book;
  return {
    title: `${bookKo} ${chapter}장`,
    verses: [
      { n: 1, t: `(${bookKo} ${chapter}장 본문을 data/bible.js에 추가해 주세요. 개역한글은 공공도메인이므로 자유롭게 입력 가능합니다.)` },
    ],
    stub: true,
  };
}

// Prefill stubs for all planned chapters so the app never crashes
window.BIBLE.plan.forEach(({ book, chapter }) => {
  const key = `${book}-${chapter}`;
  if (!window.BIBLE.chapters[key]) {
    window.BIBLE.chapters[key] = stubChapter(book, chapter);
  }
});

// Key verses for each chapter (used in home preview)
window.BIBLE.keyVerses = {
  'mark-1': { n: 15, t: '때가 찼고 하나님 나라가 가까왔으니 회개하고 복음을 믿으라' },
};

// Helper: get chapter by day index (0-based)
window.BIBLE.getDay = function(dayIndex) {
  const day = Math.max(0, Math.min(dayIndex, this.plan.length - 1));
  const plan = this.plan[day];
  const ch = this.chapters[`${plan.book}-${plan.chapter}`];
  const bookInfo = this.books[plan.book];
  return {
    day: day + 1,
    book: plan.book,
    bookKo: bookInfo.ko,
    bookShort: bookInfo.short,
    chapter: plan.chapter,
    title: ch?.title || `${bookInfo.ko} ${plan.chapter}장`,
    verses: ch?.verses || [],
    stub: ch?.stub || false,
    keyVerse: this.keyVerses[`${plan.book}-${plan.chapter}`],
    ref: `${bookInfo.ko} ${plan.chapter}장`,
    refShort: `${bookInfo.short} ${plan.chapter}장`,
  };
};
